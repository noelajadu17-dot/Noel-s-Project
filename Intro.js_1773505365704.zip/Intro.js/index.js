// intro.js
const name = "Noel Gabriel";
const age = 22; 
const favoriteLanguage = "JavaScript";

